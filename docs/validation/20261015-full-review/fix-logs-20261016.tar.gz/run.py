import subprocess, os, sys, json, time, pathlib
root=pathlib.Path(__file__).parent
label,name,rel,*cmd=sys.argv[1:]
env=os.environ.copy()
env['CCROUTER_HOME']=str(root/'coordination'/label)
env.pop('CCROUTER_PUB_HOOK_DISABLE',None)
sdk=('<USER_HOME>/fvm/versions/ohos/oh-3.41.9-release' if label.endswith('-ohos') else '<USER_HOME>/fvm/versions/3.41.9')
env['FLUTTER_ROOT']=sdk
env['PATH']=sdk+'/bin:'+env.get('PATH','')
log=root/'logs'/(label+'-'+name+'.log')
start=time.time()
with log.open('w') as stream:
 stream.write('cwd: '+str(root/label/rel)+'\ncommand: '+repr(cmd)+'\n'); stream.flush()
 process=subprocess.run(cmd,cwd=root/label/rel,env=env,stdout=stream,stderr=subprocess.STDOUT)
result={'label':label,'name':name,'cwd':str(root/label/rel),'command':cmd,'exit_code':process.returncode,'seconds':round(time.time()-start,2),'log':str(log)}
(root/'logs'/(label+'-'+name+'.json')).write_text(json.dumps(result,indent=2))
print(json.dumps(result))
print(''.join(log.read_text(errors='replace').splitlines(keepends=True)[-12:]))
sys.exit(process.returncode)
