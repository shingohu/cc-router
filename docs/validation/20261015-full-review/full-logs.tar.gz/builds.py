import sys,pathlib,subprocess
root=pathlib.Path(__file__).parent
label=sys.argv[1]
flutter='<USER_HOME>/fvm/versions/3.41.9/bin/flutter'
jobs=[('resolve','.',flutter,'pub','get')]
if label=='build-main':
 jobs += [('web','demo',flutter,'build','web','--debug','--no-pub'),('android','demo',flutter,'build','apk','--debug','--no-pub'),('macos','demo',flutter,'build','macos','--debug','--no-pub')]
else:
 jobs += [('android','demo',flutter,'build','apk','--debug','--no-pub','-t','lib/main_predictive_back.dart'),('ios','demo',flutter,'build','ios','--debug','--no-codesign','--no-pub','-t','lib/main_predictive_back.dart')]
for name,rel,*cmd in jobs:subprocess.run([sys.executable,str(root/'run.py'),label,name,rel,*cmd])
