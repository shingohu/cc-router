import subprocess,sys,pathlib
root=pathlib.Path(__file__).parent
label=sys.argv[1]
dart='<USER_HOME>/fvm/versions/3.41.9/bin/dart'
flutter='<USER_HOME>/fvm/versions/3.41.9/bin/flutter'
jobs=[
('demo','.',flutter,'test','--no-pub','--reporter=expanded','demo'),
('devtools','.',flutter,'test','--no-pub','--reporter=expanded','packages/ccrouter_devtools/test'),
('protocol','.',dart,'test','--reporter=expanded','packages/ccrouter_devtools_protocol/test'),
('tools','.',dart,'test','--reporter=expanded','tool/test'),
('docs','.',dart,'tool/documentation_check.dart'),
('release','.',dart,'tool/release_sensitivity_check.dart'),
('plugin-analyze','packages/ccrouter_analyzer_plugin',dart,'analyze'),
('generator','.',dart,'test','--concurrency=1','--reporter=expanded','packages/ccrouter_test/generator_test'),
('generate-cached','.',dart,'packages/ccrouter_generator/bin/ccrouter_generator.dart','generate','demo','--check'),
('generate-reference','.',dart,'packages/ccrouter_generator/bin/ccrouter_generator.dart','generate','demo','--no-cache','--check'),
]
for name,rel,*cmd in jobs:
 if label=='main' and name=='generator':
  # Real-server tests read Demo indexes; wait until they finish before mutation tests.
  import time
  while not (root/'logs/main-plugin-tests.json').exists():time.sleep(1)
 subprocess.run([sys.executable,str(root/'run.py'),label,name,rel,*cmd])
