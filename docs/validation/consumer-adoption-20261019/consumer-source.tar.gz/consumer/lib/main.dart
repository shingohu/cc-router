import 'package:ccrouter/ccrouter.dart';
import 'package:ccrouter/ccrouter_host.dart';
import 'package:ccrouter_go_router/ccrouter_go_router.dart';
import 'package:adoption_contracts/adoption_contracts.dart';
import 'package:flutter/material.dart';
import 'src/ccrouter_generated/ccrouter_host.api.g.dart';
const hostComponent = CCComponent(id: CCComponentId('adoption_host'), version: '0.1.0', dependencies: [detailComponentId]);
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  CCRouterHost.initialize(hostAssembly: ccrouterGeneratedHostAssembly);
  runApp(const CCGoRouterApp());
}
