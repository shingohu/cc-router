export 'src/detail_contract.dart' show detailComponentId;
export 'src/ccrouter_generated/adoption_contracts.contracts.api.g.dart' show DetailRoute;
