import 'package:ccrouter_contracts/ccrouter_contracts.dart';
const detailComponentId = CCComponentId('adoption_detail');
@CCRouteContract<String>(
  componentId: detailComponentId,
  id: 'adoption.detail',
  pattern: CCPathPattern('/details/:itemId'),
)
abstract class DetailRouteContract {
  const DetailRouteContract({required this.itemId, @CCQueryParam() this.fail = false});
  final int itemId;
  final bool fail;
}
