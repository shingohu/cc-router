import 'dart:async';
import 'package:ccrouter/ccrouter.dart';
import 'package:adoption_contracts/adoption_contracts_owner.dart';
import 'package:flutter/material.dart';
const component = CCComponent(id: detailComponentId, version: '0.1.0');
final class ResourceProbe {
  static int live = 0;
  static int disposed = 0;
}
final class DetailUnavailable implements Exception {}
@CCService(id: 'adoption.detail.resource', scope: CCServiceScope.route)
final class DetailResource implements CCDisposable {
  DetailResource() { ResourceProbe.live++; }
  final Timer timer = Timer.periodic(const Duration(seconds: 1), (_) {});
  bool _closed = false;
  String load(int id, bool fail) {
    if (fail) throw DetailUnavailable();
    return 'Item $id';
  }
  @override
  void dispose() {
    if (_closed) return;
    _closed = true;
    timer.cancel();
    ResourceProbe.live--;
    ResourceProbe.disposed++;
  }
}
@CCRouteImplementation(DetailRouteContract)
final class DetailPage extends StatelessWidget {
  const DetailPage({required this.itemId, this.fail = false, super.key});
  final int itemId;
  final bool fail;
  @override
  Widget build(BuildContext context) {
    final resource = CCRouter.routeService<DetailResource>(context);
    String label;
    try { label = resource.load(itemId, fail); }
    on DetailUnavailable { label = 'Retry required'; }
    return Scaffold(body: Column(children: [
      Text(label),
      FilledButton(onPressed: () => CCRouter.navigator.pop(result: 'confirmed:$itemId'), child: const Text('Done')),
      TextButton(onPressed: () => CCRouter.navigator.pop(), child: const Text('Cancel')),
    ]));
  }
}
