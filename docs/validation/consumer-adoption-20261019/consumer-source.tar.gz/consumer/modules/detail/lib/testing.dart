export 'src/detail.dart' show ResourceProbe;
