import 'package:ccrouter/ccrouter.dart';
import 'package:ccrouter/ccrouter_host.dart';
import 'package:ccrouter_go_router/ccrouter_go_router.dart';
import 'package:adoption_contracts/adoption_contracts.dart';
import 'package:adoption_detail/testing.dart';
import 'package:adoption_host/src/ccrouter_generated/ccrouter_host.api.g.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
void main() {
  setUp(() {
    ResourceProbe.live = 0;
    ResourceProbe.disposed = 0;
    CCRouterHost.initialize(hostAssembly: ccrouterGeneratedHostAssembly);
  });
  tearDown(() async { await CCRouterHost.shutdown(); expect(ResourceProbe.live, 0); });
  Future<void> mount(WidgetTester tester) async {
    await tester.pumpWidget(CCGoRouterApp(initialLocation: '/', hostRoutes: [GoRoute(path: '/', builder: (_, _) => const Scaffold(body: Text('Home')))]));
    await tester.pumpAndSettle();
  }
  testWidgets('typed result releases exact Route Service', (tester) async {
    await mount(tester);
    final result = CCRouter.navigator.push<String>(DetailRoute.intent(itemId: 7));
    await tester.pumpAndSettle();
    expect(find.text('Item 7'), findsOneWidget);
    expect(ResourceProbe.live, 1);
    await tester.tap(find.text('Done')); await tester.pumpAndSettle();
    expect(await result, 'confirmed:7');
    expect(ResourceProbe.live, 0); expect(ResourceProbe.disposed, 1);
    await tester.pumpWidget(const SizedBox.shrink()); await tester.pumpAndSettle();
  });
  testWidgets('cancel and reopen use independent resources', (tester) async {
    await mount(tester);
    for (var id = 1; id <= 2; id++) {
      final result = CCRouter.navigator.push<String>(DetailRoute.intent(itemId: id));
      await tester.pumpAndSettle(); expect(ResourceProbe.live, 1);
      await tester.tap(find.text('Cancel')); await tester.pumpAndSettle();
      expect(await result, isNull); expect(ResourceProbe.live, 0);
    }
    expect(ResourceProbe.disposed, 2);
    await tester.pumpWidget(const SizedBox.shrink()); await tester.pumpAndSettle();
  });
  testWidgets('business failure remains on page and cleanup still runs', (tester) async {
    await mount(tester);
    final result = CCRouter.navigator.push<String>(DetailRoute.intent(itemId: 9, fail: true));
    await tester.pumpAndSettle(); expect(find.text('Retry required'), findsOneWidget);
    expect(ResourceProbe.live, 1);
    await tester.tap(find.text('Cancel')); await tester.pumpAndSettle();
    expect(await result, isNull); expect(ResourceProbe.live, 0);
    await tester.pumpWidget(const SizedBox.shrink()); await tester.pumpAndSettle();
  });
  testWidgets('shutdown completes pending result and releases resource', (tester) async {
    await mount(tester);
    final result = CCRouter.navigator.push<String>(DetailRoute.intent(itemId: 3));
    final completion = expectLater(result, throwsA(isA<CCNavigationAdapterError>()));
    await tester.pumpAndSettle(); expect(ResourceProbe.live, 1);
    await CCRouterHost.shutdown(); await completion;
    expect(ResourceProbe.live, 0); expect(ResourceProbe.disposed, 1);
    await tester.pumpWidget(const SizedBox.shrink()); await tester.pumpAndSettle();
  });
}
