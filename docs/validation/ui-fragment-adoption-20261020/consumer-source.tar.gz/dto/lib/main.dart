import 'package:ccrouter/ccrouter_host.dart';
import 'package:adoption_dashboard/adoption_dashboard.dart';
import 'package:flutter/material.dart';
import 'src/ccrouter_generated/ccrouter_host.api.g.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  CCRouterHost.initialize(hostAssembly: ccrouterGeneratedHostAssembly);
  runApp(const AdoptionApp());
}

final class AdoptionApp extends StatelessWidget {
  const AdoptionApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    home: Scaffold(
      body: SelectionPair(
        firstItem: 'featured',
        onFirstAction: (_) {},
        onSecondAction: (_) {},
      ),
    ),
  );
}
