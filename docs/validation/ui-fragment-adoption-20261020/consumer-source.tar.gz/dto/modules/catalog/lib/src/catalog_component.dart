import 'package:ccrouter/ccrouter.dart';
import 'package:adoption_fragment_contracts/owner.dart';

const catalogComponent = CCComponent(id: catalogComponentId, version: '0.1.0');
