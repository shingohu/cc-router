import 'dart:async';
import 'package:adoption_fragment_contracts/selection_card_fragment.dart';
import 'package:ccrouter_ui/ccrouter_ui.dart';
import 'package:flutter/material.dart';

@CCUIFragmentRenderer(SelectionCardFragmentContract)
Widget renderSelectionCard(
  CCUIFragmentRenderInput<SelectionCardProps, SelectionCardAction> input,
) => _CatalogCard(
  query: input.props.itemId,
  active: input.active,
  onAction: input.onAction,
);

final class _CatalogCard extends StatefulWidget {
  const _CatalogCard({
    required this.query,
    required this.active,
    required this.onAction,
  });
  final String query;
  final bool active;
  final ValueChanged<SelectionCardAction> onAction;
  @override
  State<_CatalogCard> createState() => _CatalogCardState();
}

final class _CatalogCardState extends State<_CatalogCard> {
  Timer? _request;
  int _revision = 0;
  String? _selectedId;
  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(_CatalogCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.query != widget.query) {
      _selectedId = null;
      _load();
    } else if (oldWidget.active != widget.active) {
      if (!widget.active) {
        _request?.cancel();
        _revision++;
      } else if (_selectedId == null) {
        _load();
      }
    }
  }

  void _load() {
    _request?.cancel();
    final revision = ++_revision;
    if (!widget.active) return;
    final query = widget.query;
    _request = Timer(const Duration(milliseconds: 40), () {
      if (!mounted || revision != _revision) return;
      setState(
        () => _selectedId = query == 'new' ? 'private-8426' : 'private-7301',
      );
    });
  }

  @override
  void dispose() {
    _revision++;
    _request?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => TextButton(
    onPressed: widget.active && _selectedId != null
        ? () => widget.onAction(SelectionCardAction(selectedId: _selectedId!))
        : null,
    child: Text(
      _selectedId == null ? 'Loading ${widget.query}' : 'Pick ${widget.query}',
    ),
  );
}
