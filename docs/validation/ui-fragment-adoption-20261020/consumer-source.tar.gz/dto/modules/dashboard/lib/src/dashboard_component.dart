import 'package:ccrouter/ccrouter.dart';
import 'package:ccrouter_ui/ccrouter_ui.dart';
import 'package:adoption_fragment_contracts/selection_card_fragment.dart';

const dashboardComponent = CCComponent(
  id: CCComponentId('dashboard_component'),
  version: '0.1.0',
  dependencies: [catalogComponentId],
  uiDependencies: [
    CCUIFragmentDependency<SelectionCardFragmentContract>(
      versionRange: '^2.0.0',
      alias: 'selectionCard',
    ),
  ],
);
