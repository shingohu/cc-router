import 'package:adoption_fragment_contracts/selection_card_fragment.dart';
import 'package:flutter/material.dart';
import 'package:adoption_dashboard/src/ccrouter_generated/dashboard_component.ui.api.g.dart';

/// A owns placement, activity, stable instance Keys and the business callbacks.
final class SelectionPair extends StatelessWidget {
  const SelectionPair({
    super.key,
    required this.firstItem,
    required this.onFirstAction,
    required this.onSecondAction,
    this.active = true,
  });
  final String firstItem;
  final bool active;
  final ValueChanged<SelectionCardAction> onFirstAction;
  final ValueChanged<SelectionCardAction> onSecondAction;
  @override
  Widget build(BuildContext context) => Column(
    children: [
      DashboardComponentFragments.selectionCard(
        key: const ValueKey('first'),
        props: SelectionCardProps(itemId: firstItem),
        active: active,
        onAction: onFirstAction,
      ),
      DashboardComponentFragments.selectionCard(
        key: const ValueKey('second'),
        props: const SelectionCardProps(itemId: 'new'),
        onAction: onSecondAction,
      ),
    ],
  );
}
