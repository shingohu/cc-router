import 'package:ccrouter_contracts/ccrouter_contracts.dart';

const catalogComponentId = CCComponentId('catalog_component');
