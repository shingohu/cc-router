/// Public UI Contract; implementation and generated glue remain private.
library;

export 'src/selection_card_fragment.dart'
    show SelectionCardProps, SelectionCardAction, SelectionCardFragmentContract;
export 'owner.dart' show catalogComponentId;
