import 'package:ccrouter_contracts/ccrouter_ui_contracts.dart';
import '../owner.dart' show catalogComponentId;

/// Immutable input owned and updated by the consuming component.
final class SelectionCardProps {
  const SelectionCardProps({required this.itemId});
  final String itemId;
}

/// B returns only the identifier loaded by its private backend.
final class SelectionCardAction {
  const SelectionCardAction({required this.selectedId});
  final String selectedId;
}

/// Public capability implemented only by the canonical Owner.
@CCUIFragmentContract<SelectionCardProps, SelectionCardAction>(
  componentId: catalogComponentId,
  id: 'catalog.selection',
  version: '2.0.0',
)
abstract final class SelectionCardFragmentContract {}
