import 'package:ccrouter/ccrouter.dart';
import 'package:ccrouter/ccrouter_host.dart';
import 'package:adoption_dashboard/adoption_dashboard.dart';
import 'package:ui_adoption_host/src/ccrouter_generated/ccrouter_host.api.g.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

Widget tree(
  List<String> first,
  List<String> second, {
  String query = 'featured',
  bool active = true,
  int session = 0,
}) => MaterialApp(
  home: Scaffold(
    body: SelectionPair(
      key: ValueKey(session),
      firstItem: query,
      active: active,
      onFirstAction: (action) => first.add(action.selectedId),
      onSecondAction: (action) => second.add(action.selectedId),
    ),
  ),
);
Future<void> loaded(WidgetTester tester) =>
    tester.pump(const Duration(milliseconds: 100));

void main() {
  setUp(
    () => CCRouterHost.initialize(hostAssembly: ccrouterGeneratedHostAssembly),
  );
  tearDown(CCRouterHost.shutdown);
  testWidgets(
    'private DTO selections stay isolated across activity, Props and callbacks',
    (tester) async {
      final first = <String>[];
      final second = <String>[];
      await tester.pumpWidget(tree(first, second));
      await loaded(tester);
      await tester.tap(find.text('Pick featured'));
      await tester.tap(find.text('Pick new'));
      expect(first, ['private-7301']);
      expect(second, ['private-8426']);
      await tester.pumpWidget(tree(first, second, active: false));
      await tester.tap(find.text('Pick featured'));
      expect(first, hasLength(1));
      await tester.pumpWidget(tree(first, second, query: 'new'));
      await tester.pump(const Duration(milliseconds: 20));
      await tester.pumpWidget(tree(first, second));
      await loaded(tester);
      await tester.tap(find.text('Pick featured'));
      expect(first, ['private-7301', 'private-7301']);
      final latest = <String>[];
      await tester.pumpWidget(tree(latest, second));
      await tester.tap(find.text('Pick featured'));
      expect(latest, ['private-7301']);
      expect(first, hasLength(2));
      await tester.pumpWidget(tree(latest, second, session: 1));
      expect(find.text('Loading featured'), findsOneWidget);
      await loaded(tester);
      await tester.tap(find.text('Pick featured'));
      expect(latest, hasLength(2));
      expect(CCRouter.activeRouteEntries, isEmpty);
      await tester.pumpWidget(const SizedBox());
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets('unmount cancels pending private loads', (tester) async {
    final first = <String>[];
    final second = <String>[];
    await tester.pumpWidget(tree(first, second));
    await tester.pumpWidget(const SizedBox());
    await tester.pump(const Duration(seconds: 1));
    expect(first, isEmpty);
    expect(second, isEmpty);
    expect(tester.takeException(), isNull);
  });
  testWidgets(
    'shutdown invalidates old actions and a fresh mount uses the new Host',
    (tester) async {
      final first = <String>[];
      final second = <String>[];
      await tester.pumpWidget(tree(first, second));
      await loaded(tester);
      await CCRouterHost.shutdown();
      await tester.tap(find.text('Pick featured'));
      expect(first, isEmpty);
      await tester.pumpWidget(const SizedBox());
      CCRouterHost.initialize(hostAssembly: ccrouterGeneratedHostAssembly);
      await tester.pumpWidget(tree(first, second, session: 1));
      await loaded(tester);
      await tester.tap(find.text('Pick featured'));
      expect(first, ['private-7301']);
      await tester.pumpWidget(const SizedBox());
      expect(tester.takeException(), isNull);
    },
  );
}
