import 'package:flutter/widgets.dart';
import 'package:ccrouter_ui/ccrouter_ui.dart';
import 'package:adoption_fragment_contracts/selection_card_fragment.dart';

/// Builds the Owner Widget; disposable resources belong in its State.
@CCUIFragmentRenderer(SelectionCardFragmentContract)
Widget renderSelectionCard(
  CCUIFragmentRenderInput<SelectionCardProps, SelectionCardAction> input,
) => GestureDetector(
  onTap: input.active
      ? () => input.onAction(SelectionCardAction.openDetails)
      : null,
  child: Text(input.props.itemId),
);
