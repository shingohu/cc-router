import 'package:ccrouter_contracts/ccrouter_ui_contracts.dart';
import '../owner.dart' show catalogComponentId;

/// Immutable input owned and updated by the consuming component.
final class SelectionCardProps {
  const SelectionCardProps({required this.itemId});
  final String itemId;
}

/// The consumer already knows itemId; v1 Actions cannot carry dynamic payloads.
enum SelectionCardAction { openDetails }

/// Public capability implemented only by the canonical Owner.
@CCUIFragmentContract<SelectionCardProps, SelectionCardAction>(
  componentId: catalogComponentId,
  id: 'catalog.selection',
  version: '1.0.0',
)
abstract final class SelectionCardFragmentContract {}
