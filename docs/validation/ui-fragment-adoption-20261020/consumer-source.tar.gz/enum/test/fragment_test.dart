import 'package:ccrouter/ccrouter.dart';
import 'package:ccrouter/ccrouter_host.dart';
import 'package:adoption_dashboard/adoption_dashboard.dart';
import 'package:adoption_fragment_contracts/selection_card_fragment.dart';
import 'package:ui_adoption_host/src/ccrouter_generated/ccrouter_host.api.g.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  setUp(
    () => CCRouterHost.initialize(hostAssembly: ccrouterGeneratedHostAssembly),
  );
  tearDown(CCRouterHost.shutdown);
  testWidgets('scaffold enum renders two instances and returns typed actions', (
    tester,
  ) async {
    final first = <SelectionCardAction>[];
    final second = <SelectionCardAction>[];
    Widget tree(String query, {bool active = true}) => MaterialApp(
      home: Scaffold(
        body: SelectionPair(
          firstItem: query,
          active: active,
          onFirstAction: first.add,
          onSecondAction: second.add,
        ),
      ),
    );
    await tester.pumpWidget(tree('featured'));
    await tester.tap(find.text('featured'));
    expect(first, [SelectionCardAction.openDetails]);
    expect(second, isEmpty);
    await tester.tap(find.text('new'));
    expect(second, [SelectionCardAction.openDetails]);
    await tester.pumpWidget(tree('featured', active: false));
    await tester.tap(find.text('featured'));
    expect(first, hasLength(1));
    await tester.pumpWidget(tree('changed'));
    await tester.tap(find.text('changed'));
    expect(first, hasLength(2));
    expect(CCRouter.activeRouteEntries, isEmpty);
    await tester.pumpWidget(const SizedBox());
    expect(tester.takeException(), isNull);
  });
}
